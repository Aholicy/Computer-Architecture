#pragma once
#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <sstream>
#include <windows.h>
#include <thread>
using namespace std;

struct RS
{
	bool busy;
	string op;
	string vj, vk;
	string qj, qk;
	string address;
	RS() { 
		busy = false; 
	}
};

struct RC
{
	bool busy;
	string status;
	string value;
	RC() { 
		busy = false; 
	}
};

vector<vector<string>> spilt_input(int a);

int Register_index(string a);

bool RS_ready(int index);

void instr_wait(int index);

void issue(int index);

void execute(int index, int RS_No);

void write(int index, int RS_No);

void print();

void tomasulo();
