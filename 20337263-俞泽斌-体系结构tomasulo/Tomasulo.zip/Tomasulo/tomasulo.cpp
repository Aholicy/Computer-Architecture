#pragma once
#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <windows.h>
#include <thread>
#include "tomasulo.h"
using namespace std;

const int filenum = 1;  //输入文件编号
vector<vector<string>> instr = spilt_input(filenum); //输入指令并分隔
vector<RS> Load(3);
vector<RS> Store(3);
vector<RS> Add(3);
vector<RS> Mult(2);
vector<RC> Register_condition(16);
int cycle = 1;
ofstream outfile;
int instr_size = instr.size();
vector<vector<int>> instr_cycle(instr_size, vector<int>(3, 0));//指令最终执行情况表



vector<vector<string>> spilt_input(int a)
{
	vector<vector<string>> spilt_instr;
	ifstream infile;   //流处理输入
	if (a == 1) {
		infile.open("input1.txt", ios::in);
	}
	else {
		infile.open("input2.txt", ios::in);
	}
	string line;
	string sing;
	stringstream ss;
	int index1 = 0;
	while (getline(infile, line)) {   //先分行
		spilt_instr.push_back(vector<string>(4));		
		ss << line;
		int index2 = 0;
		while (getline(ss, sing, ' ')) {
			spilt_instr[index1][index2] = sing;  //分列
			index2++;
		}
		ss.clear();
		index1++;
	}
	infile.close();//关闭输入流，防止与输出冲突
	/*
	if (a == 1) {
		outfile.open("output1.txt", ios::out);
		if (!outfile) {
			cout << "output1.txt can't open." << endl;
			abort();
		}
	}
	else {
		outfile.open("output2.txt", ios::out);
		if (!outfile) {
			cout << "output2.txt can't open." << endl;
			abort();
		}		
	}
	*/
	return spilt_instr;
}
void file_print(int a) {//流输出
	if (a == 1) {
		outfile.open("output1.txt", ios::out);
	}
	else {
		outfile.open("output2.txt", ios::out);
	}
}

bool RS_ready(int index)
{
	if (instr[index][0] == "LD") {
		for (int i = 0; i < 3; i++) {
			if (!Load[i].busy) {        //3个load之中只要有一个可用就行
				return true;
			}
		}
		return false;
	}
	if (instr[index][0] == "SD") {//3个store之中只要有一个可用就行
		for (int i = 0; i < 3; i++) {
			if (!Store[i].busy) {
				return true;
			}
		}
		return false;
	}
	if (instr[index][0] == "ADDD" || instr[index][0] == "SUBD") {
		for (int i = 0; i < 3; i++) {//同上，加法与减法公用加法器
			if (!Add[i].busy) {
				return true;
			}
		}
		return false;
	}
	if (instr[index][0] == "MULTD" || instr[index][0] == "DIVD") {
		for (int i = 0; i < 2; i++) {//同上
			if (!Mult[i].busy) {
				return true;
			}
		}
		return false;
	}
	return true;
}

int Register_index(string a)
{
	return stoi(a.substr(1)) / 2;
}



void instr_wait(int index)
{
	if (index != 0) {
		while (!RS_ready(index) || instr_cycle[index - 1][0] == 0 || cycle < instr_cycle[index - 1][0] + 1);//等待ready状态
		int now_cycle = cycle;
		if (now_cycle - instr_cycle[index - 1][0] > 1) {
			while (cycle != now_cycle + 1);//等待一个周期
		}
	}
	thread t = thread(issue, index);
	t.join();
}

void issue(int index)
{
	int now_cycle = cycle;
	cout << "issue" << index << " " << now_cycle << endl;
	instr_cycle[index][0] = now_cycle;
	int RS_No = 0;
	if (instr[index][0] == "ADDD" || instr[index][0] == "SUBD") {
		for (RS_No = 0; RS_No < 3; RS_No++) {	//寻找一个空闲的加法器
			if (Add[RS_No].busy == false) {
				break;
			}
		}
		Add[RS_No].busy = true;//将此时选中的加法器改成busy状态
		Add[RS_No].op = instr[index][0];
		Register_condition[Register_index(instr[index][1])].busy = true;
		Register_condition[Register_index(instr[index][1])].status = "Add" + to_string(RS_No + 1);//以下开始更新每个RS
		if (Register_condition[Register_index(instr[index][2])].busy) {
			Add[RS_No].vj = "";
			Add[RS_No].qj = Register_condition[Register_index(instr[index][2])].status;
		}
		else {
			Add[RS_No].vj = Register_condition[Register_index(instr[index][2])].value;
			Add[RS_No].qj = "";
		}
		if (Register_condition[Register_index(instr[index][3])].busy) {
			Add[RS_No].vk = "";
			Add[RS_No].qk = Register_condition[Register_index(instr[index][3])].status;
		}
		else {
			Add[RS_No].vk = Register_condition[Register_index(instr[index][3])].value;
			Add[RS_No].qk = "";
		}
	}
	if (instr[index][0] == "MULTD" || instr[index][0] == "DIVD") {
		for (RS_No = 0; RS_No < 2; RS_No++) {
			if (Mult[RS_No].busy == false) {  //寻找一个空闲的乘法器
				break;
			}
		}
		Mult[RS_No].busy = true;
		Mult[RS_No].op = instr[index][0];
		//更新寄存器状态
		Register_condition[Register_index(instr[index][1])].busy = true;
		Register_condition[Register_index(instr[index][1])].status = "Mult" + to_string(RS_No + 1);
		if (Register_condition[Register_index(instr[index][2])].busy) {
			Mult[RS_No].vj = "";
			Mult[RS_No].qj = Register_condition[Register_index(instr[index][2])].status;
		}
		else {
			Mult[RS_No].vj = Register_condition[Register_index(instr[index][2])].value;
			Mult[RS_No].qj = "";
		}
		if (Register_condition[Register_index(instr[index][3])].busy) {
			Mult[RS_No].vk = "";
			Mult[RS_No].qk = Register_condition[Register_index(instr[index][3])].status;
		}
		else {
			Mult[RS_No].vk = Register_condition[Register_index(instr[index][3])].value;
			Mult[RS_No].qk = "";
		}
	}
	if (instr[index][0] == "LD") {
		for (RS_No = 0; RS_No < 3; RS_No++) {
			if (Load[RS_No].busy == false) {//寻找一个空闲的load
				break;
			}
		}
		Load[RS_No].busy = true;
		if (instr[index][2] == "0") {
			Load[RS_No].address = "M(" + instr[index][3] + ")";//判断是否有偏移量，方便之后直接输出位置
		}
		else {
			Load[RS_No].address = "M(" + instr[index][2] + instr[index][3] + ")";
		}
		//更新寄存器状态
		Register_condition[Register_index(instr[index][1])].status = "Load" + to_string(RS_No + 1);
		Register_condition[Register_index(instr[index][1])].busy = true;
	}
	if (instr[index][0] == "SD") {
		for (RS_No = 0; RS_No < 3; RS_No++) {
			if (Store[RS_No].busy == false) {//寻找一个空闲的store
				break;
			}
		}
		Store[RS_No].busy = true;
		if (instr[index][1] == "0") {
			Store[RS_No].address = "M(" + instr[index][3] + ")";
		}
		else {
			Store[RS_No].address = "M(" + instr[index][2] + instr[index][3] + ")";
		}
		if (Register_condition[Register_index(instr[index][1])].busy) {
			Store[RS_No].vj = "";
			Store[RS_No].qj = Register_condition[Register_index(instr[index][1])].status;
		}
		else {
			Store[RS_No].vj = Register_condition[Register_index(instr[index][1])].value;
			Store[RS_No].qj = "";
		}
	}
	
	thread t = thread(execute, index, RS_No);
	t.join();
}

void execute(int index, int RS_No)
{
	int now_cycle = cycle;
	Sleep(10);
	now_cycle = cycle;
	//execution latency 
	if (instr[index][0] == "LD") {
		while (cycle != now_cycle + 2);	
	}
	if (instr[index][0] == "SD") {
		while (Store[RS_No].qj != "");//先等qj为空
		now_cycle = cycle;
		while (cycle != now_cycle + 2);
	}
	if (instr[index][0] == "ADDD" || instr[index][0] == "SUBD") {		
		while (Add[RS_No].qj != "" || Add[RS_No].qk != "");//先等qj和qk均为空
		now_cycle = cycle;
		while (cycle != now_cycle + 2);
	}
	if (instr[index][0] == "MULTD" || instr[index][0] == "DIVD") {
		while (Mult[RS_No].qj != "" || Mult[RS_No].qk != "");//等qj和qk均为空
		now_cycle = cycle;
		if (instr[index][0] == "MULTD") {
			while (cycle != now_cycle + 10);
		}
		else {
			while (cycle != now_cycle + 20);
		}
	}
	
	cout << "execute" << index << " " << cycle << endl;
	instr_cycle[index][1] = cycle;
	thread t = thread(write, index, RS_No);
	t.join();
}

void write(int index, int RS_No)
{
	int now_cycle = cycle;
	string t_address;
	string t_status;
	while (cycle != now_cycle + 1);
	Sleep(20);
	cout << "write" << index << " " << cycle << endl;
	instr_cycle[index][2] = cycle;   //最终每条指令输出的write周期
	while (cycle != now_cycle + 1);  //等待一周期
	if (instr[index][0] == "LD") {
		t_status = "Load" + to_string(RS_No + 1);   
		t_address = Load[RS_No].address;
		for (int i = 0; i < 16; i++) {
			if (Register_condition[i].busy && Register_condition[i].status == t_status) {  //以寄存器状态作为判断条件。然后添加寄存器的值
				Register_condition[i].busy = false;
				Register_condition[i].status = "";
				Register_condition[i].value = t_address;
			}
		}
		Load[RS_No].address = "";
		Load[RS_No].busy = false;
	}
	if (instr[index][0] == "SD") {
		t_status = "Store" + to_string(RS_No + 1);//SD指令不需要改变寄存器
		Store[RS_No].address = "";
		Store[RS_No].busy = false;
		Store[RS_No].vj = "";
	}
	if (instr[index][0] == "ADDD" || instr[index][0] == "SUBD") {
		t_status = "Add" + to_string(RS_No + 1);
		if (instr[index][0] == "ADDD") { //加法or减法
			t_address = Add[RS_No].vj + "+" + Add[RS_No].vk;
		}
		else {
			t_address = Add[RS_No].vj + "-" + Add[RS_No].vk;
		}
		for (int i = 0; i < 16; i++) {//以寄存器状态作为判断条件。然后添加寄存器的值
			if (Register_condition[i].busy && Register_condition[i].status == t_status) {
				Register_condition[i].busy = false;
				Register_condition[i].status = "";
				Register_condition[i].value = t_address;
			}
		}
		Add[RS_No].busy = false;  //重新将寄存器的值归0，表明空闲
		Add[RS_No].op = "";
		Add[RS_No].vj = "";
		Add[RS_No].vk = "";
	}
	if (instr[index][0] == "MULTD" || instr[index][0] == "DIVD") {
		t_status = "Mult" + to_string(RS_No + 1);
		if (instr[index][0] == "MULTD") {  //乘法 or 除法
			t_address = Mult[RS_No].vj + "*" + Mult[RS_No].vk;
		}
		else {
			t_address = Mult[RS_No].vj + "/" + Mult[RS_No].vk;
		}
		for (int i = 0; i < 16; i++) {
			if (Register_condition[i].busy && Register_condition[i].status == t_status) {
				Register_condition[i].busy = false;
				Register_condition[i].status = "";
				Register_condition[i].value = t_address;
			}
		}
		Mult[RS_No].busy = false;
		Mult[RS_No].op = "";
		Mult[RS_No].vj = "";
		Mult[RS_No].vk = "";
	}
	for (int i = 0; i < 3; i++) {
		if (Add[i].qj == t_status) {   //更新加法器的状态
			Add[i].qj = "";
			Add[i].vj = t_address;
		}
		if (Add[i].qk == t_status) {
			Add[i].qk = "";
			Add[i].vk = t_address;
		}
	}
	for (int i = 0; i < 2; i++) {//更新乘法器的状态
		if (Mult[i].qj == t_status) {
			Mult[i].qj = "";
			Mult[i].vj = t_address;
		}
		if (Mult[i].qk == t_status) {
			Mult[i].qk = "";
			Mult[i].vk = t_address;
		}
	}
	for (int i = 0; i < 3; i++) {
		if (Store[i].qj == t_status) {//更新store的状态
			Store[i].qj = "";
			Store[i].vj = t_address;
		}
	}
}

void print()
{
	
	for (int i = 0; i < 3; i++) {	//输出RS中load信息
		cout << "Load" << to_string(i + 1) << ":";
		outfile << "Load" << to_string(i + 1) << ":";
		if (Load[i].busy) {
			cout << "Yes";
			outfile << "Yes";
		}
		else {
			cout << "No";
			outfile << "No";
		}
		cout << "," + Load[i].address + ";" << endl;
		outfile << "," + Load[i].address + ";" << endl;
	}

	for (int i = 0; i < 3; i++) {	//输出RS中store信息
		cout << "Store" << to_string(i + 1) << ":";
		outfile << "Store" << to_string(i + 1) << ":";
		if (Store[i].busy) {
			cout << "Yes";
			outfile << "Yes";
		}
		else {
			cout << "No";
			outfile << "No";
		}
		cout << "," + Store[i].address + ";" << endl;
		outfile << "," + Store[i].address + ";" << endl;
	}

	for (int i = 0; i < 3; i++) {//输出RS中ADD信息
		cout << "Add" << to_string(i + 1) << ":";
		outfile << "Add" << to_string(i + 1) << ":";
		if (Add[i].busy) {
			cout << "Yes";
			outfile << "Yes";
		}
		else {
			cout << "No";
			outfile << "No";
		}
		cout << "," + Add[i].op + "," + Add[i].vj + "," + Add[i].vk + "," + Add[i].qj + "," + Add[i].qk + ";" << endl;
		outfile << "," + Add[i].op + "," + Add[i].vj + "," + Add[i].vk + "," + Add[i].qj + "," + Add[i].qk + ";" << endl;
	}
	for (int i = 0; i < 2; i++) { //输出Mult信息
		cout << "Mult" << to_string(i + 1) << ":";
		outfile << "Mult" << to_string(i + 1) << ":";
		if (Mult[i].busy) {
			cout << "Yes";
			outfile<< "Yes";
		}
		else {
			cout << "No";
			outfile << "No";
		}
		cout << "," + Mult[i].op + "," + Mult[i].vj + "," + Mult[i].vk + "," + Mult[i].qj + "," + Mult[i].qk + ";" << endl;
		outfile << "," + Mult[i].op + "," + Mult[i].vj + "," + Mult[i].vk + "," + Mult[i].qj + "," + Mult[i].qk + ";" << endl;
	}
	for (int i = 0; i < 16; i++) {    //FU的输出，各个寄存器
		if (Register_condition[i].busy) {
			cout << "F" << i * 2 << ":" + Register_condition[i].status;
			outfile << "F" << i * 2 << ":" + Register_condition[i].status;
		}
		else if (Register_condition[i].value != "") {
			cout << "F" << i * 2 << ":" + Register_condition[i].value;
			outfile << "F" << i * 2 << ":" + Register_condition[i].value;
		}
		else {
			cout << "F" << i * 2 << ":";
			outfile << "F" << i * 2 << ":";
		}
		cout << ";";
		outfile << ";";
	}
	cout << endl;
	outfile << endl;
}

void tomasulo()
{
	vector<thread> threads(instr_size);
	file_print(filenum);
	int precycle = 0;
	int cycle_flag[100];
	memset(cycle_flag, 0, sizeof(cycle_flag));  //防止重复输出同一个周期
	for (cycle; cycle <= instr_size; cycle++) {
		threads[cycle - 1] = thread(instr_wait, cycle - 1);  //创建线程，并行执行
		Sleep(80);
		for (int i = 0; i < instr_cycle.size(); i++) {   //取巧做法，直接用指令的每个阶段的周期来表示发生改变的位置，输出那几个周期的内容
			for (int j = 0; j < instr_cycle[i].size(); j++) {
				if (cycle == instr_cycle[i][j]&&cycle_flag[cycle]==0) {
					cycle_flag[cycle] = 1;
					if (cycle - precycle == 1) {
						if (cycle != 1) {       //没有持续的相同输出
							cout << "no continued same output " << endl;
							outfile << "no continued same output " << endl;
							cout << endl;
							outfile << endl;
						}												
						cout << "cycle_" << cycle << ";" << endl;
						outfile << "cycle_" << cycle << ";" << endl;
						print();
						precycle = cycle;
					}
					else {  //有持续的相同周期并且输出最后一个相同周期编号至末尾
						cout << "same output until cycle_" << cycle - 1 << endl;
						outfile << "same output until cycle_" << cycle - 1 << endl;
						cout << endl;
						outfile << endl;
						cout << "cycle_" << cycle << ";" << endl;
						outfile << "cycle_" << cycle << ";" << endl;
						print();
						precycle = cycle;
					}
				}
			}
		}
	}	
	//print();
	Sleep(20);

	while (cycle <= 60) {
		Sleep(80);   //没有指令需要读入，只用考虑输出情况，下面代码和上半部分基本一致
		for (int i = 0; i < instr_cycle.size(); i++) {
			for (int j = 0; j < instr_cycle[i].size(); j++) {
				if (cycle == instr_cycle[i][j] && cycle_flag[cycle] == 0) {
					cycle_flag[cycle] = 1;
					if (cycle - precycle == 1) {
						cout << "no continued same output " << endl;
						outfile << "no continued same output " << endl;
						cout << endl;
						outfile << endl;
						cout << "cycle_" << cycle << ";" << endl;
						outfile << "cycle_" << cycle << ";" << endl;
						print();
						precycle = cycle;
					}
					else {
						cout << "same output until cycle_" << cycle - 1 << endl;
						outfile << "same output until cycle_" << cycle - 1 << endl;
						cout << endl;
						outfile << endl;
						cout << "cycle_" << cycle << ";" << endl;
						outfile << "cycle_" << cycle << ";" << endl;
						print();
						precycle = cycle;
					}
				}
			}
		}
		Sleep(20);
		cycle++;
	}
	for (auto& th : threads) {
		th.join();
	}

	for (int i = 0; i < instr_size; i++) {  //输出最后的各个指令各个阶段的周期编号（指令最终执行情况表）
		for (int j = 0; j < 4; j++) {
			cout << instr[i][j] << " ";
			outfile << instr[i][j] << " ";
		}
		cout << ":";
		outfile << ":";
		for (int j = 0; j < 3; j++) {
			cout << instr_cycle[i][j] << " ";
			outfile << instr_cycle[i][j] << " ";
		}
		cout << endl;
		outfile << endl;
	}
	outfile.close();//关闭输出流
}