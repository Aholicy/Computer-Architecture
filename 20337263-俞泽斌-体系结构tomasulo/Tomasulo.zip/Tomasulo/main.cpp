#pragma once
#include <iostream>
#include <vector>
#include <set>
#include <fstream>
#include <string>
#include <sstream>
#include "tomasulo.h"
using namespace std;

int main()
{
	tomasulo();
}